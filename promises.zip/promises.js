const fs = require('node:fs');
= "C:\Users\leont\ÜK_Backend_2024\heyo";

function leseDateiInhalt(path) {
    return new Promise((resolve, reject) =>{
        const ergebnis = fs.readFile(path, 'utf8')
        resolve(ergebnis);
    }, 20);
}

const reader = fs.readFile(argument);
const stringFile = file.toString();
const argList = stringFile.split('\n');
console.log(argList.length);